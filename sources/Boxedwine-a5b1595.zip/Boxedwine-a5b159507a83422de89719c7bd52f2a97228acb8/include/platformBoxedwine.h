/*
 *  Copyright (C) 2012-2026  The BoxedWine Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef __PLATFORM_H__
#define __PLATFORM_H__

#include <cstdio>
#include <string>

#ifdef __EMSCRIPTEN__
#define MAX_FILEPATH_LEN 256
#else
#define MAX_FILEPATH_LEN 1024
#endif

// maximum number of files per directory
#define MAX_DIR_LISTING 4096

#include "platformtypes.h"
#define FD S32

#ifdef __APPLE__
#define lseek64 lseek
#endif

// Tail-call dispatch support.
// PRESERVE_NONE: callee saves no registers, enabling zero-cost tail dispatch.
// MUSTTAIL: forces the compiler to emit a tail call rather than call+return.
#if defined(__clang__) && defined(__has_attribute)
#if __has_attribute(preserve_none)
#define PRESERVE_NONE __attribute__((preserve_none))
#else
#define PRESERVE_NONE
#endif
#else
#define PRESERVE_NONE
#endif

#if defined(__has_cpp_attribute) && __has_cpp_attribute(clang::musttail)
#define MUSTTAIL [[clang::musttail]]
#elif defined(__has_cpp_attribute) && __has_cpp_attribute(gnu::musttail)
#define MUSTTAIL [[gnu::musttail]]
#else
#define MUSTTAIL
#endif

// BOXEDWINE_DIRECT_NORMAL_DISPATCH below is the per-opcode return_call dispatcher
// used by NEXT(); it is enabled only for non-JIT Emscripten builds. WASM JIT builds
// (BOXEDWINE_JIT defined) instead chain through NEXT_INTERP_CHAIN (normalCPU.cpp),
// but share the same preserve_none OPCALL — see the OPCALL definition below for why
// preserve_none is ABI-safe for the WASM JIT.
//
// on win32 with msvc without JIT, BOXEDWINE_DIRECT_NORMAL_DISPATCH caused a 50% loss in performance for Quake 2.
// BOXEDWINE_NO_DIRECT_NORMAL_DISPATCH is a diagnostic opt-out so the
// dispatcher's contribution can be measured in isolation, e.g.
//   make -B multiThreaded GCC_EXTRA_FLAGS=-DBOXEDWINE_NO_DIRECT_NORMAL_DISPATCH
#if !defined(BOXEDWINE_JIT) && defined(__EMSCRIPTEN__) && !defined(BOXEDWINE_NO_DIRECT_NORMAL_DISPATCH)
#define BOXEDWINE_DIRECT_NORMAL_DISPATCH 1
#endif

#ifdef BOXEDWINE_MSVC
#include <codeanalysis\warnings.h>
#pragma warning(disable:26451) 
#pragma warning(disable:6297) 
#define OPCALL __fastcall
#define ftruncate(h, l) _chsize(h, (long)l)
#define lseek64 _lseeki64
#define platform_getcwd _getcwd
#define UNISTD <io.h>
#define UTIME <sys/utime.h>
#define CURDIR_INCLUDE <direct.h>
#define MKDIR_INCLUDE <direct.h>
#define RMDIR_INCLUDE <direct.h>
#define INLINE __inline
#define NO_INLINE __declspec(noinline)
#define OPENGL_CALL_TYPE __stdcall
#define PACKED( s ) __pragma( pack(push, 1) ) s __pragma( pack(pop) )
#define ALIGN(t, x) __declspec(align(x)) t
#define strcasecmp stricmp
#define strncasecmp strnicmp
char* platform_strcasestr(const char* s1, const char* s2);
#define strcasestr platform_strcasestr
#else
#define ALL_CODE_ANALYSIS_WARNINGS 0
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#include <limits.h>
#if ( __WORDSIZE == 64 )
#define BOXEDWINE_64   1
#endif
// Direct-dispatch builds use preserve_none for opcode handlers. The WASM JIT can
// too: its startJITOp is the C++ wasmStartJITOp (not generated machine code), and
// generated blocks are reached via pfnJitCode/call_indirect (never via op->pfn), so
// all OpCallback calls are C++ and stay ABI-consistent. The native x32/armv8 JIT —
// whose startJITOp IS generated code cast to OpCallback and must keep the default
// ABI — is excluded from WASM_JIT builds, so this is safe. (EXPERIMENT: forward perf.)
#if defined(BOXEDWINE_DIRECT_NORMAL_DISPATCH) || defined(BOXEDWINE_WASM_JIT)
#define OPCALL PRESERVE_NONE
#else
#define OPCALL
#endif
#define platform_getcwd getcwd
#define UNISTD <unistd.h>
#define UTIME <utime.h>
#define CURDIR_INCLUDE <unistd.h>
#define MKDIR_INCLUDE <sys/stat.h>
#define RMDIR_INCLUDE <unistd.h>
#define O_BINARY 0
#define INLINE inline
#define NO_INLINE __attribute__((noinline))
#define OPENGL_CALL_TYPE
#define PACKED( s ) s __attribute__((__packed__))
#define ALIGN(t, x) t __attribute__((aligned(x)))
#endif

#ifndef S_ISDIR
# define S_ISDIR(ST_MODE) (((ST_MODE) & _S_IFMT) == _S_IFDIR)
#endif

class FsNode;
class KThread;

#ifdef BOXEDWINE_MSVC
struct _stat32i64;
struct _utimbuf;
#else
struct stat;
struct utimbuf;
#endif

#ifdef BOXEDWINE_MULTI_THREADED
#define NUMBER_OF_MILLIES_TO_SPIN_FOR_WAIT 20
#elif defined(__EMSCRIPTEN__)
// A spin would busy wait on the browser's main thread and stop every other
// emulated thread with it, so even a 1 ms sleep waits on a timer
#define NUMBER_OF_MILLIES_TO_SPIN_FOR_WAIT 0
#else 
#define NUMBER_OF_MILLIES_TO_SPIN_FOR_WAIT 2
#endif

class Platform {
public:
#ifdef BOXEDWINE_MSVC
    using Stat = struct _stat32i64;
    using Utimbuf = struct _utimbuf;
    // Convert only at the host API boundary; guest/native path bookkeeping stays unchanged.
    static std::wstring nativeFilePath(const char* path, bool forceExtendedLength = false);
#else
    using Stat = struct stat;
    using Utimbuf = struct utimbuf;
#endif
    // Host filesystem operations preserve the native return value and errno.
    static int open(const char* path, int flags, int mode = 0666);
    static FILE* fopen(const char* path, const char* mode);
    static int access(const char* path, int mode);
    static int stat(const char* path, Stat* buf);
    static int unlink(const char* path);
    static int rename(const char* from, const char* to);
    static int mkdir(const char* path);
    static int rmdir(const char* path);
    static int utime(const char* path, Utimbuf* times);

    class ListNodeResult {
    public:
        ListNodeResult(BString name, bool isDirectory) : name(name), isDirectory(isDirectory) {}
        BString name;
        bool isDirectory;
    };
    static void init();
    static void listNodes(BString nativePath, std::vector<ListNodeResult>& results);    
    static int nativeSocketPair(S32 socks[2]);
    static U32 getCpuFreqMHz();
    static U32 getCpuCurScalingFreqMHz(U32 cpuIndex);
    static U32 getCpuMaxScalingFreqMHz(U32 cpuIndex);
    static U32 getCpuCount();
    static void openFileLocation(BString location);
    static bool supportsOpenFileLocation() {return true;}
    static BString getResourceFilePath(BString location);
    static void setCurrentThreadPriorityHigh();
    using WriteCodeCallback = void (*)(void* context) noexcept;
    static void writeCodeToMemory(void* address, U32 len, std::function<void()> callback);
    static void writeCodeToMemory(void* address, U32 len, WriteCodeCallback callback, void* context) noexcept;
    static void clearInstructionCache(void* address, U32 len);
#if defined(__TEST) && defined(BOXEDWINE_MSVC)
    static void resetTestInstructionCacheClearCount();
    static U32 getTestInstructionCacheClearCount();
#endif
    static U32 nanoSleep(U64 nano);
    static U32 getPageAllocationGranularity();
    static U32 getPagePermissionGranularity(); // assumed to be smaller or equal to getPageAllocationGranularity and that getPageAllocationGranularity / getPagePermissionGranularity is a whole number
    static U32 allocateNativeMemory(U64 address); // page must be aligned to Platform::getAllocationGranularity
    static U32 updateNativePermission(U64 address, U32 permission, U32 len = 0); // page must be aligned to Platform::getPagePermissionGranularity.  when len == 0, it will default to getPagePermissionGranularity() << K_PAGE_SHIFT
    static void releaseNativeMemory(void* address, U64 len);
    static U8* alloc64kBlock(U32 count, bool executable = false);
    static BString procStat();
    static U8* reserveNativeMemory64k(U32 count);
    static void commitNativeMemoryPage(void* address);
    static int getL1CacheSize();
#ifdef BOXEDWINE_MULTI_THREADED
    static void setCpuAffinityForThread(KThread* thread, U32 count);
#endif
private:
    friend class KSystem;

    static U64 getSystemTimeAsMicroSeconds();
    static U64 getMicroCounter();
    static void startMicroCounter();
};

#include <string.h>
#include "log.h"

INLINE void safe_strcpy(char* dest, const char* src, size_t bufferSize) {
    size_t len = strlen(src);
    if (len+1>bufferSize) {
        kpanic_fmt("safe_strcpy failed to copy %s, buffer is %zu bytes", src, bufferSize);
    }
    strcpy(dest, src);
}

INLINE void safe_strcat(char* dest, const char* src, size_t bufferSize) {
    size_t len = strlen(src)+strlen(dest);
    if (len+1>bufferSize) {
        kpanic_fmt("safe_strcat failed to copy %s, buffer is %zu bytes", src, bufferSize);
    }
    strcat(dest, src);
}

#if defined(BOXEDWINE_X64) || defined(BOXEDWINE_JIT_X64)
bool platformHasBMI2();
#endif

#ifdef BOXEDWINE_MULTI_THREADED
void ATOMIC_WRITE64(U64* pTarget, U64 value);

using PlatformThreadFunction = void* (*)(void*);
// Entry receives CPU* after native handle/affinity setup. On success it may
// already have exited and deleted the KThread/CPU before this call returns.
S32 platformStartThread(KThread* thread, PlatformThreadFunction entry);
#ifdef __TEST
void platformJoinThread(KThread* thread);
void platformSetTestBeforeThreadHandlePublishedHook(const std::function<void()>& hook);
#endif
#endif

#ifdef BOXEDWINE_MIDI
void PlayMsg(U8* msg);
void PlaySysex(U8 * sysex,U32 len);
#endif

#if defined(BOXEDWINE_JIT_ARMV8) && defined(BOXEDWINE_MSVC)
U64 get_ID_AA64ISAR0_EL1();
U64 get_ID_AA64ISAR1_EL1();
#endif

#define VECTOR_CONTAINS(v, o) (std::find(v.begin(), v.end(), o) != v.end())
#define VECTOR_REMOVE(v, o) v.erase(std::remove(v.begin(), v.end(), o), v.end())
#define VECTOR_TO_ARRAY_ON_STACK(v, t, r) r = (t*)alloca(v.size()*sizeof(t)); std::copy(v.begin(), v.end(), r)

#define DEFAULT_POLL_RATE 0
#define DEFAULT_POLL_RATE_str "0"

bool isMainthread();
#endif
