/*
 *  Copyright (C) 2012-2025  The BoxedWine Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef __PLAYER_H__
#define __PLAYER_H__

#ifdef BOXEDWINE_RECORDER
class Player {
public:
    static bool start(BString directory);
    static Player* instance;

    void initCommandLine(BString root, const std::vector<BString>& zips, BString working, const std::vector<BString>& args);
    void runSlice();
    void quit();

    BReadFile file;
    std::vector<BString> scriptLines;
    BString directory;
    BString version;
    U64 lastCommandTime = 0;
    U32 lastCommandWallTime = 0;
    U64 lastScreenRead = 0;
    U32 lastScreenshotLogTime = 0;
    BString nextCommand;
    U32 currentInputModifiers = 0;
    U32 scriptLineIndex = 0;
    bool useVirtualFiles = false;
private:    
    BString nextValue;
    std::thread comparingThread;
    U32 nextWaitTime = 0;
    U32 timerWhileWaiting = 0;
    U32 waitMouseX = 0;
    U32 waitMouseY = 0;
    U32 waitKey = 0;
    bool processWaitCommand = false;
    BString waitCommand;

    void readCommand();        
};
#endif

#endif