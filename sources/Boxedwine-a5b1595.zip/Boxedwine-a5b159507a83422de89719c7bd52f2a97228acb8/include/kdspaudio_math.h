/*
 *  Copyright (C) 2012-2026  The BoxedWine Team
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 */

#ifndef __KDSPAUDIO_MATH_H__
#define __KDSPAUDIO_MATH_H__

namespace KDspAudioMath {
	struct WorkletBufferLayout {
		U32 fragmentBytes;
		U32 capacityBytes;
	};

	inline WorkletBufferLayout getWorkletBufferLayout(U32 rate, U32 frameSize) {
		// OSS clients cache this geometry. It must depend only on the negotiated
		// PCM format, never on underruns or a change of host output backend.
		U32 frames = (U32)((U64)rate * 30 / 1000);
		U32 fragmentFrames = 1;
		while (fragmentFrames < (frames + 2) / 3) fragmentFrames <<= 1;
		U32 capacityFrames = frames < fragmentFrames * 2 ? fragmentFrames * 2 : frames;
		return {fragmentFrames * frameSize, capacityFrames * frameSize};
	}

	// Wine's OSS driver keeps only one or two 10 ms periods queued, but the browser can
	// stop the main thread, and Wine with it, for 20-30 ms, for example to collect
	// garbage. Frames up to this reserve are hidden from the guest, so it writes that
	// much further ahead and the worklet keeps playing through such a pause. Each ms
	// of reserve is also a ms of audio latency; 10 ms was not enough.
	inline U32 getGuestVisibleQueuedFrames(U32 queuedFrames, U32 rate) {
		U32 reserveFrames = (U32)((U64)rate * 20 / 1000);
		return queuedFrames > reserveFrames ? queuedFrames - reserveFrames : 0;
	}

	inline U32 getRequestedSdlPeriodFrames() {
#ifdef __EMSCRIPTEN__
		return 4096;
#else
		return 1024;
#endif
	}

	inline U32 getAlignedDurationBytes(U32 bytesPerSecond, U32 durationMs, U32 frameSize) {
		if (!frameSize) {
			return 0;
		}
		U32 bytes = (U32)((U64)bytesPerSecond * durationMs / 1000);
		return bytes & ~(frameSize - 1);
	}

	inline U32 getWriteCapacity(U32 bytesPerSecond, U32 fragmentSize, U32 bufferSize) {
		U32 capacity = bytesPerSecond / 8;
		if (capacity < fragmentSize) {
			capacity = fragmentSize;
		}
		if (capacity > bufferSize) {
			capacity = bufferSize;
		}
		return capacity;
	}

	inline U32 getAvailableWriteBytes(U32 capacity, U32 queued) {
		return queued >= capacity ? 0 : capacity - queued;
	}

	inline U32 getOutputSpaceAvailable(U32 capacity, U32 used, bool accountForQueuedAudio) {
		return accountForQueuedAudio ? getAvailableWriteBytes(capacity, used) : capacity;
	}

	inline U32 getQueuedAfterElapsed(U32 queued, U32 bytesPerSecond, U32 elapsedMs) {
		U64 consumed = (U64)bytesPerSecond * elapsedMs / 1000;
		return consumed >= queued ? 0 : queued - (U32)consumed;
	}

	inline U32 alignWriteBytes(U32 bytes, U32 blockSize) {
		if (!blockSize) {
			return 0;
		}
		return bytes & ~(blockSize - 1);
	}

	inline U32 getWritableBytes(U32 requested, U32 capacity, U32 queued, U32 blockSize) {
		U32 available = getAvailableWriteBytes(capacity, queued);
		U32 writable = requested < available ? requested : available;
		return alignWriteBytes(writable, blockSize);
	}
}

#endif
